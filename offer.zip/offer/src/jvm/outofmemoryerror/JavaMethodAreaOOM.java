package jvm.outofmemoryerror;

import com.sun.deploy.security.EnhancedJarVerifier;
//类似于groovy语言持续创建类来实现语言的动态性
public class JavaMethodAreaOOM {
    public static void main(String[] args) {
        while (true){
        }
    }
}
